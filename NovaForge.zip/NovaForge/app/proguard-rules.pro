# Nova Forge alpha: release shrinking is intentionally disabled.
